# Build Guide — Power BI Desktop

## 1. Import the dataset
1. Extract this project folder to a permanent location, for example `C:\PowerBI\Sales_Analysis_Report_2020`.
2. Open Power BI Desktop.
3. Select **Home → Get data → Text/CSV**.
4. Select `data/sales_2020.csv`, then choose **Transform Data**.
5. Confirm `OrderDate` is Date, `Quantity` is Whole Number, and currency/amount columns are Decimal Number or Fixed Decimal Number.
6. Select **Close & Apply**. Rename the loaded table to `Sales` if needed.

## 2. Add date table and measures
1. Select **Modeling → New table** and paste the `Calendar = ...` expression from `dax/Sales_Measures.dax`.
2. Select **Table tools → Mark as date table**, choose `Calendar[Date]`.
3. Create relationship `Calendar[Date]` (one) to `Sales[OrderDate]` (many).
4. Create each measure from `Sales_Measures.dax` using **Modeling → New measure**. Paste one measure at a time.
5. Select `Calendar[Month]` and choose **Sort by column → Month Number**.

## 3. Create report visuals
Use a 16:9 page (Format page → Canvas settings → 16:9), light background, and optional theme from `assets/sales_theme.json` (View → Themes → Browse for themes).

- **Header:** Text box “Sales Analysis Report 2020”.
- **KPI cards:** `[Total Sales]`, `[Total Profit]`, `[Total Orders]`, `[Total Customers]`, `[Profit Margin %]`.
- **Monthly trend:** Line chart — X-axis `Calendar[Month]`, Y-axis `[Total Sales]`.
- **Regional sales:** Clustered bar chart — Y-axis `Sales[Region]`, X-axis `[Total Sales]`.
- **Top 5 customers:** Bar chart — Y-axis `Sales[CustomerName]`, X-axis `[Top 5 Customers Sales]`; visual filter `Top 5 Customer Rank` is less than or equal to 5 (or use Top N filter by Total Sales).
- **Top 5 products:** Bar chart — Y-axis `Sales[ProductName]`, X-axis `[Top 5 Products Sales]`; visual filter `Top 5 Product Rank` is less than or equal to 5.
- **Slicers:** `Calendar[Month]`, `Sales[Region]`, `Sales[Category]`, `Sales[SalesChannel]`.

## 4. Add bookmark navigation (optional)
1. Create two report views/pages or two visual states (Overview and Details).
2. Select **View → Bookmarks** and **View → Selection**.
3. Set visibility of visuals for the Overview state; add a bookmark named `Overview`.
4. Change visibility for the Details state; add a bookmark named `Details`.
5. Insert **Buttons → Navigator → Bookmark navigator**, or add buttons and set Action = Bookmark with the matching bookmark.
6. Test each button in reading mode (Ctrl+click while editing).

## 5. Save
Save as `dashboard/Sales_Analysis_Report_2020.pbix` (create the `dashboard` folder first). Reopen the saved PBIX to confirm it loads and visuals respond to slicers.

## 6. GitHub upload
### Browser method
1. Sign in at https://github.com and create a repository named `sales-analysis-report-2020`.
2. Set it to Public if this is for a portfolio and the dataset is synthetic.
3. Choose **Add file → Upload files**.
4. Upload the project files/folders and the completed `.pbix` if allowed.
5. Commit with message `Add Power BI Sales Analysis Report 2020`.

### Git command line (run in PowerShell from the project folder)
```powershell
git init
git add .
git commit -m "Add Power BI Sales Analysis Report 2020"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/sales-analysis-report-2020.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username. If the remote already exists, use `git remote set-url origin ...`.

### Large PBIX files
GitHub blocks ordinary files over 100 MB. If your PBIX is larger than 100 MB, use Git LFS:
```powershell
git lfs install
git lfs track "*.pbix"
git add .gitattributes
git add dashboard/Sales_Analysis_Report_2020.pbix
git commit -m "Track Power BI report with Git LFS"
git push
```
