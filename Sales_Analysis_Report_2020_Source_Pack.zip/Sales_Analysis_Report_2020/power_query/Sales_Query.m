let
    Source = Csv.Document(
        File.Contents("C:\\PowerBI\\Sales_Analysis_Report_2020\\data\\sales_2020.csv"),
        [Delimiter=",", Columns=14, Encoding=65001, QuoteStyle=QuoteStyle.Csv]
    ),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    ChangedTypes = Table.TransformColumnTypes(
        PromotedHeaders,
        {
            {"OrderID", type text}, {"OrderDate", type date},
            {"CustomerName", type text}, {"ProductName", type text},
            {"Category", type text}, {"Region", type text}, {"City", type text},
            {"SalesChannel", type text}, {"Quantity", Int64.Type},
            {"UnitPrice", Currency.Type}, {"DiscountPct", Percentage.Type},
            {"SalesAmount", Currency.Type}, {"CostAmount", Currency.Type},
            {"Profit", Currency.Type}
        }
    )
in
    ChangedTypes
