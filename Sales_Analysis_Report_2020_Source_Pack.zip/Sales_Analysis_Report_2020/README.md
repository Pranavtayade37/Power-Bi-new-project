# Sales Analysis Report 2020 — Power BI

A beginner-friendly recreation of the one-page interactive sales report concept from the reference tutorial. Includes a 2020 sample dataset, DAX measures, Power Query M, theme JSON, and build instructions.

> **Important:** This source pack does not contain a `.pbix` file. A genuine Power BI Desktop `.pbix` must be created and saved in Microsoft Power BI Desktop. The included files are the complete inputs and formulas needed to build it; no fake or empty PBIX is included.

## Project files

- `data/sales_2020.csv` — 1,000 synthetic sales transactions for 2020.
- `dax/Sales_Measures.dax` — KPI, time-intelligence, and Top 5 measures.
- `power_query/Sales_Query.m` — Power Query M import/type conversion example.
- `assets/sales_theme.json` — optional report theme.
- `BUILD_GUIDE.md` — step-by-step report layout and build steps.

## Dashboard layout

Suggested 16:9 single-page report:
1. Header: **Sales Analysis Report 2020** and year/date slicer.
2. KPI cards: Total Sales, Total Profit, Total Orders, Total Customers, Profit Margin.
3. Monthly sales trend: line chart using Calendar[Month] and [Total Sales].
4. Sales by region: clustered bar chart using Region and [Total Sales].
5. Top 5 customers: bar chart with CustomerName and [Top 5 Customers Sales].
6. Top 5 products: bar chart with ProductName and [Top 5 Products Sales].
7. Category and SalesChannel slicers.
8. Buttons/bookmarks to switch between Overview and Details views (optional).

## Data note

The dataset is synthetic and generated for learning/portfolio use. It is not the original video creator's dataset, so exact totals and screenshots will differ. The reference tutorial describes Excel import, DAX, CALCULATE, DISTINCT, SUM, RANKX, Top 5 customers/products, bookmarks, and buttons.

## Build

Follow `BUILD_GUIDE.md`. When finished, save the report as:
`dashboard/Sales_Analysis_Report_2020.pbix`

## GitHub

Upload the project folder to a new GitHub repository. Keep the CSV, DAX, M, theme, and README in GitHub. Add the `.pbix` if its size is within GitHub's file limits; for larger files, use Git LFS or attach it to a GitHub Release. Never upload confidential customer data.

## Credits

Inspired by the public tutorial concept: https://youtu.be/hhZ6EDiVboI
